import importlib.util

spec = importlib.util.spec_from_file_location('otop', 'otop.py')
otop = importlib.util.module_from_spec(spec)
spec.loader.exec_module(otop)


def test_run_metric_detail():
    assert otop.run_metric_detail({}) == 'Tokens: warten auf Provider · Tok/s: n/a'
    text = otop.run_metric_detail({'prompt_tokens': 1000, 'output_tokens': 250,
                                   'eval_duration_s': 5})
    assert text == 'Tokens: 1.2k (Prompt 1.0k, Ausgabe 250) · 50.0 Tok/s'
    text = otop.run_metric_detail({'prompt_tokens': 10, 'output_tokens': 3})
    assert text == 'Tokens: 13 (Prompt 10, Ausgabe 3) · Tok/s: n/a'
    assert 'Prompt n/a' in otop.run_metric_detail({'output_tokens': 3})
    estimated = {'context_tokens_estimate': 250, 'output_tokens_estimate': 50,
                 'estimate_quality': 'estimated'}
    assert otop.context_values(estimated, {'context_length': 1000}) == (250, 1000, 25.0, 'estimated')
    assert '≈ geschätzt' in otop.context_text(estimated, {'context_length': 1000})


import asyncio
import json
import os
import pathlib
import sys
import tempfile
import threading
import types
from contextlib import contextmanager
from unittest.mock import patch


@contextmanager
def isolated_state():
    with tempfile.TemporaryDirectory(dir=os.environ.get("TMPDIR")) as directory:
        env = {"XDG_STATE_HOME": directory, "OTOP_HISTORY_FILE": directory + "/history.jsonl",
               "OTOP_RUN_FILE": directory + "/run.jsonl", "OTOP_RUN_HISTORY_FILE": directory + "/runs.jsonl",
               "OTOP_OPEN_WEBUI_DB": ""}
        with patch.dict(os.environ, env):
            otop._estimate_runs.clear()
            yield directory


def event(run_id, kind="started", **values):
    return dict(schema=2, source="pi", model="test-model", run_id=str(run_id),
                event=kind, started_at=otop._utc_now(), **values)


def test_measurement_and_streams():
    body = {"messages": [{"id": "not-context", "role": "user", "content": [
        {"type": "text", "text": "Grüße"}, {"type": "image_url", "image_url": {"url": "data:secret"}}]}]}
    assert otop.measure_prompt(body) == (5, True)
    run = {"stream_chars": 0}
    for text in ("abc", "abc", "abcdef"):
        otop.count_stream(run, {"message": {"content": text, "thinking": text}})
    assert run["stream_chars"] == 12
    run = {"stream_chars": 0}
    for _ in range(2):
        otop.count_stream(run, {"done": False, "message": {"content": "ha"}})
    assert run["stream_chars"] == 4  # legitimate repeated deltas
    otop.count_stream(run, {"message": {"content": "haha!"}})
    assert run["stream_chars"] == 5  # mixed delta and cumulative snapshot
    chunk = {"sequence_id": 7, "choices": [{"delta": {"content": "x", "reasoning_content": "y"}}]}
    otop.count_stream(run, chunk); otop.count_stream(run, chunk)
    assert run["stream_chars"] == 7
    otop.count_stream(run, {"choices": [{"delta": {"tool_calls": [{"function": {"arguments": "{}"}}]}}]})
    assert run["output_partial"]


def test_calibration_and_privacy():
    with isolated_state():
        assert otop.process_run_event(event(1, prompt_chars=80, output_chars=0, context_limit=128))
        assert otop.load_run_events()[0]["context_tokens_estimate"] == 20
        assert otop.process_run_event(event(1, "updated", output_chars=80))
        assert otop.load_run_events()[0]["context_limit"] == 128
        final = event(1, "completed", prompt_chars=80, output_chars=80, prompt_eval_count=40, eval_count=40)
        assert otop.process_run_event(final)
        run = otop.load_run_history()[0]
        assert run["context_tokens"] == 80 and run["estimate_error_percent"] == -50
        factors = otop.load_calibration()
        assert factors["test-model"]["output_chars_per_token"] == 3.6
        assert otop.process_run_event(final)
        assert otop.load_calibration() == factors
        assert otop.process_run_event(event(2, prompt_chars=80, output_chars=0))
        assert otop.load_run_events()[0]["estimate_quality"] == "calibrated"
        assert otop.process_run_event(event(2, "completed", output_chars=80, prompt_tokens=40, output_tokens=40))
        assert abs(otop.load_run_history()[0]["estimate_error_percent"]) < 50
        factors = otop.load_calibration()
        for run_id, status in ((3, "cancelled"), (4, "error")):
            otop.process_run_event(event(run_id, prompt_chars=80, output_chars=0))
            otop.process_run_event(event(run_id, status, output_chars=80))
        assert otop.load_calibration() == factors
        otop.process_run_event(event(5, prompt_chars=80, prompt_partial=True, output_partial=True))
        otop.process_run_event(event(5, "completed", output_chars=80, prompt_tokens=40, output_tokens=40))
        assert otop.load_calibration() == factors
        assert otop.load_run_history()[0]["estimate_partial"]
        for path in (otop.run_path(), otop.run_history_path(), otop.calibration_path()):
            data = pathlib.Path(path).read_text()
            assert '"prompt_chars"' not in data and '"output_chars"' not in data
            assert pathlib.Path(path).stat().st_mode & 0o777 == 0o600
        output_factor = factors["test-model"]["output_chars_per_token"]
        for run_id, invalid in ((6, 40), (7, float("nan"))):
            otop.process_run_event(event(run_id, prompt_chars=80, output_chars=80))
            otop.process_run_event(event(run_id, "completed", output_chars=invalid, prompt_tokens=40, output_tokens=40))
            assert otop.load_calibration()["test-model"]["output_chars_per_token"] == output_factor
        otop.process_run_event(event(8, prompt_chars=1, output_chars=0))
        assert otop.load_run_events()[0]["context_tokens_estimate"] == 1
        changed = event(8, "updated"); changed["model"] = "another-model"
        assert otop.process_run_event(changed) is False
        pathlib.Path(otop.calibration_path()).write_text('{broken')
        assert otop.load_calibration() == {}
        assert "output_tokens" not in otop.normalize_run(event(6, output_tokens=float("inf")))
        legacy = otop.normalize_run({"schema": 1, "model": "old", "run_id": "old", "prompt_tokens": 3, "output_tokens": 2})
        assert legacy["source"] == "legacy" and legacy["context_tokens"] == 5
        old_schema2 = otop.normalize_run(event(9, prompt_tokens=3, output_tokens=2))
        assert old_schema2["context_tokens"] == 5


class FakeScreen:
    def __init__(self, height, width):
        self.height = height
        self.width = width
        self.rows = [[" "] * width for _ in range(height)]
        self.writes = []

    def erase(self):
        self.rows = [[" "] * self.width for _ in range(self.height)]
        self.writes.clear()

    def getmaxyx(self):
        return self.height, self.width

    def addstr(self, y, x, text, _attr=0):
        self.writes.append((y, x, text))
        for index, char in enumerate(text):
            if 0 <= x + index < self.width:
                self.rows[y][x + index] = char

    def refresh(self):
        pass

    def text(self):
        return ["".join(row).rstrip() for row in self.rows]


def test_history_separation_and_layout():
    ollama = {"ok": True, "version": "test", "error": None, "models": []}
    record = otop.snapshot_record("http://test", ollama, 1.0, (2.0, 3.0, 2.0), [], None)
    assert "run" not in record
    with isolated_state() as directory:
        old = dict(record, run={"run_id": "legacy-live"})
        assert otop.write_history(old)
        assert otop.write_history(record)
        rows = list(otop.read_jsonl(os.path.join(directory, "history.jsonl")))
        assert rows[0]["run"]["run_id"] == "legacy-live"
        assert "run" not in rows[-1]

    colors = {key: 0 for key in ("structure", "secondary", "status_green", "status_yellow",
                                  "error", "offload_good", "offload_mixed", "offload_cpu")}
    now = otop._utc_now()
    live = {"source": "open-webui", "run_id": "live", "model": "test-model",
            "status": "running", "updated_at": now, "age_seconds": 0.1,
            "context_tokens_estimate": 100, "output_tokens_estimate": 20,
            "context_limit": 4096, "estimate_quality": "estimated"}
    final = {"source": "open-webui", "run_id": "final", "model": "test-model",
             "status": "completed", "finished_at": now, "prompt_tokens": 10,
             "output_tokens": 20, "context_tokens": 30, "context_limit": 4096}
    gpu = {"util": 5, "name": "GPU", "temp_c": 45.0, "mem_total": 1000.0,
           "mem_used": 100.0, "vram_pct": 10.0, "power_watt": 20.0,
           "power_limit": 100.0, "source": "test"}
    model = {"name": "test-model", "size": 1000, "size_vram": 1000,
             "context_length": 4096, "runner": "test", "details": {}}
    for height, width in ((18, 40), (18, 80), (20, 80), (40, 120)):
        screen = FakeScreen(height, width)
        state = {"colors": colors, "help": False, "cpu": 10.0, "cpu_temp": 50.0,
                 "cpu_temp_source": "test", "ram": (20.0, 32.0, 25.0),
                 "gpus": [gpu, gpu], "gpu_err": None,
                 "ollama": {"ok": True, "error": None, "version": "test",
                            "models": [model, model]},
                 "runs": [dict(live, run_id=str(index)) for index in range(3)],
                 "run_history": [dict(final, run_id=str(index)) for index in range(3)],
                 "history_ok": True, "collector_status": "aktiv", "adapter_status": "aktiv"}
        otop._draw(screen, state, "http://test", 2.0)
        text = screen.text()
        live_row = next(index for index, line in enumerate(text) if "Open WebUI" in line and "running" in line)
        context_row = next(index for index, line in enumerate(text) if "Kontext" in line and "geschätzt" in line)
        history_row = next(index for index, line in enumerate(text) if "History" in line)
        assert live_row < context_row < history_row
        assert sum("History" in line for line in text) == 1
        assert all(y < history_row for y, _x, value in screen.writes if "running" in value or "geschätzt" in value)


def test_parallel_events():
    with isolated_state():
        threads = [threading.Thread(target=otop.process_run_event, args=(event(i, prompt_chars=80),)) for i in range(12)]
        for thread in threads: thread.start()
        for thread in threads: thread.join()
        assert len(otop.load_run_events(limit=20)) == 12
        server = otop.ThreadingHTTPServer(("127.0.0.1", 0), otop.collector_handler("test-token"))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f"http://127.0.0.1:{server.server_port}/v1/runs"
        try:
            request = otop.urllib.request.Request(url, data=json.dumps(event(20, prompt_chars=80)).encode())
            try:
                otop.urllib.request.urlopen(request)
            except otop.urllib.error.HTTPError as exc:
                assert exc.code == 401
            else:
                raise AssertionError("missing authentication")
            request.add_header("Authorization", "Bearer test-token")
            with otop.urllib.request.urlopen(request) as response:
                assert response.status == 202
        finally:
            server.shutdown()
            server.server_close()


def load_adapter():
    # No installation required on hosts without Open WebUI / pydantic.
    class BaseModel:
        def __init__(self):
            for key, value in type(self).__dict__.items():
                if not key.startswith("_"): setattr(self, key, value)
    stub = types.SimpleNamespace(BaseModel=BaseModel, Field=lambda default_factory: default_factory())
    spec = importlib.util.spec_from_file_location("test_adapter", "open_webui/otop_run_metrics.py")
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, {"pydantic": stub}): spec.loader.exec_module(module)
    return module


def test_adapter_rounds_and_abort():
    adapter = load_adapter()
    async def check():
        f = adapter.Filter()
        events = []
        async def send(value): events.append(value)
        f._send = send
        model = {"id": "test-model", "owned_by": "ollama"}
        body = {"model": "test-model", "messages": [{"role": "user", "content": "a" * 80}]}
        request = object()
        for _ in range(2):  # tool-loop provider rounds sharing request metadata
            await f.request(body, {}, model, request)
            await f.stream({"choices": [{"delta": {"content": "x" * 80}}]}, {}, model, request)
            await f.stream({"choices": [{"delta": {}, "finish_reason": "stop"}],
                            "usage": {"prompt_tokens": 40, "completion_tokens": 40}}, {}, model, request)
        await f.outlet(body, {}, model, request)
        finals = [e for e in events if e["event"] == "completed"]
        assert len(finals) == 2 and len({e["run_id"] for e in finals}) == 2
        first, second = object(), object()
        await f.request(body, {}, model, first); await f.request(body, {}, model, second)
        for req in (first, second):
            await f.stream({"choices": [], "usage": {"prompt_tokens": 10, "completion_tokens": 0}}, {}, model, req)
        assert len([e for e in events if e["event"] == "completed"]) == 4
        class Disconnected:
            async def is_disconnected(self): return True
        await f.request(body, {}, model, Disconnected())
        await asyncio.sleep(.6)
        assert events[-1]["event"] == "cancelled"
        await f.request(body, {"message_id": "hidden-thinking"}, model)
        await f.stream({"choices": [], "usage": {"prompt_tokens": 40, "completion_tokens": 40,
                       "completion_tokens_details": {"reasoning_tokens": 20}}}, {"message_id": "hidden-thinking"}, model)
        assert events[-1]["output_partial"]
        assert adapter.find_metrics({"usage": {"prompt_tokens": 0, "completion_tokens": 0}}) == {"prompt_tokens": 0, "output_tokens": 0}
        assert adapter.find_metrics({"done": True, "usage": {"prompt_tokens": 2, "completion_tokens": 3}}) == {"prompt_tokens": 2, "output_tokens": 3}
        assert adapter.find_metrics({"messages": [{"usage": {"prompt_tokens": 999}}, {"content": "new answer"}]}) is None
        assert adapter.find_metrics({"tool_calls": [{"arguments": {"usage": {"prompt_tokens": 999}}}]}) is None
    asyncio.run(check())


if __name__ == "__main__":
    tests = [value for name, value in list(globals().items()) if name.startswith("test_") and callable(value)]
    for test in tests:
        test()
    print(f"OK: {len(tests)} Testgruppen")

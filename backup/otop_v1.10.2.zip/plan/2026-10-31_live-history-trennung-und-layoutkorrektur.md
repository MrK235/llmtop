# Plan: Live-Anzeige und History wieder sauber trennen

## Ziel

Die Regression gegenüber dem dokumentierten Stand 1.10.0 wird gezielt behoben:

- laufende Runs bleiben unter **Aktuelle Runs** sichtbar,
- abgeschlossene Runs erscheinen ausschließlich unter **History**,
- System-Snapshots enthalten keine Kopie eines aktiven Runs,
- bei kleinen Terminals überschreibt kein Bereich einen bereits gezeichneten Bereich.

Es wird nur die bestehende Single-File-Struktur korrigiert; keine neue Funktion und keine zusätzliche Abhängigkeit.

## Analysegrundlage

Ein direkter Quellvergleich mit 1.10.0 ist im Projekt nicht möglich: Das Git-Repository besitzt keine Commits oder Tags, und `Archiv.zip` enthält `otop.py` in Version 1.7.0. Der Befund basiert deshalb auf dem aktuellen Code 1.10.1, der dokumentierten Trennung seit 1.5.0 sowie einer reproduzierten Mock-Ausgabe für kleine Terminalhöhen.

## Gefundene Fehler

### 1. Der Renderer setzt den Zeilenzähler rückwärts

In `_draw()` wird nach der Live-Anzeige ausgeführt:

```python
row = min(row, h - 4)
```

Wenn die aktuellen Runs bereits bis unter `h - 4` reichen, springt `row` zurück. Anschließend werden **Geladene Modelle** und später **History** auf Zeilen geschrieben, die schon Live-Daten enthalten.

**Folge:** Die Live-Haupt- oder Kontextzeile wird überschrieben und wirkt leer beziehungsweise unvollständig.

### 2. Die History wird nachträglich in bereits belegte Zeilen verschoben

Wenn unterhalb der Modelle nicht genug Platz bleibt, setzt der Code:

```python
history_row = max(1, h - wanted - 1)
```

Dabei wird nicht geprüft, ob diese Zeile bereits von **Aktuelle Runs** oder **Geladene Modelle** belegt ist. Der Kommentar, die aktuelle Run-Anzeige bleibe unverändert, entspricht nicht dem tatsächlichen Verhalten.

Reproduzierbar ist bereits bei 18–19 Zeilen eine Doppelbelegung der Zeile durch **Geladene Modelle** und **History**. Bei mehreren aktiven Runs überschreibt die History zusätzlich deren Zeilen.

### 3. Die Platzreservierung berücksichtigt die Live-Anzeige nicht

Die GPU- und Modellschleifen verwenden feste Grenzen wie `h - 9` und `h - 5`. Der tatsächliche Platzbedarf hängt aber von der Anzahl aktiver Runs und deren Kontext-Unterzeilen ab.

**Folge:** Zusätzliche GPUs, Modelle oder parallele Runs konkurrieren um dieselben unteren Zeilen. Die gewünschte Priorität „erster Live-Run vor Modellen, History und Fußzeile sichtbar“ ist nicht zuverlässig umgesetzt.

### 4. System-History enthält Live-Run-Daten

`snapshot_record()` besitzt das Feld `"run": run`. Sowohl TUI als auch `--once` übergeben den ersten aktiven Run an jeden System-Snapshot.

Damit wird derselbe laufende Run gleichzeitig in:

- `run.jsonl` als Live-Zustand und
- `history.jsonl` innerhalb eines System-Snapshots

gespeichert. Das widerspricht der dokumentierten Trennung von System-Snapshots und Run-History. Abgeschlossene Runs gehören ausschließlich nach `runs.jsonl`.

### 5. Die bestehenden Tests erkennen Zeilenüberschreibungen nicht

Die Tests prüfen Metriken, Collector und Adapter, aber nicht die endgültige Belegung der TUI-Zeilen. Ein PTY-Test auf Start und Beenden kann erfolgreich sein, obwohl Überschriften oder Live-Zeilen später im selben Frame überschrieben werden.

## Korrektur in drei Schritten

### Schritt 1 – Datenhaltung trennen

- Das aktive `run`-Objekt aus `snapshot_record()` entfernen.
- TUI und `--once` schreiben nur System-, Ollama- und Sensordaten nach `history.jsonl`.
- Live-Runs bleiben ausschließlich in `run.jsonl`; finale Runs ausschließlich in `runs.jsonl`.
- Vorhandene alte Snapshots mit einem `run`-Feld bleiben lesbar und werden nicht migriert oder gelöscht.

### Schritt 2 – Layout ohne Rücksprünge rendern

- Den History-Bereich einschließlich Fußzeile vorab von unten reservieren.
- Eine feste obere Grenze für den Ollama-Inhalt berechnen.
- **Aktuelle Runs** nur innerhalb dieser Grenze zeichnen; mindestens die erste Haupt- und Kontextzeile priorisieren.
- Danach nur noch passende Modellkarten anzeigen.
- GPU-Karten bei Bedarf früher kürzen, statt spätere Bereiche zurück auf belegte Zeilen zu setzen.
- `row = min(...)` und das nachträgliche Zurücksetzen von `history_row` entfernen.
- Kein Bereich darf auf eine Zeile schreiben, die einem anderen Bereich zugeordnet wurde.

### Schritt 3 – Gezielte Regressionstests

Im Scratch-Verzeichnis einen kleinen Fake-curses-Screen verwenden und mindestens prüfen:

- Größen 40×18, 80×18, 80×20 und 120×40,
- 0, 1 und 3 aktive Runs,
- 0, 1 und mehrere History-Runs,
- mehrere GPUs und geladene Modelle,
- erster Live-Run samt Kontextzeile bleibt sichtbar,
- History beginnt immer unterhalb der Live-Anzeige,
- Überschriften teilen keine Zeile,
- keine Schreiboperation springt aus einem späteren Bereich in einen früheren zurück,
- neue System-Snapshots enthalten kein `run`-Feld,
- alte Snapshots mit `run`-Feld verursachen weiterhin keinen Fehler.

Danach die Projektprüfungen ausführen:

```bash
python3 -m py_compile otop.py
python3 test_otop.py
python3 otop.py --version
python3 otop.py --once
python3 otop.py --once --no-nvidia
```

## Betroffene Dateien bei der Umsetzung

- `otop.py`
- `test_otop.py` nur für die gezielte Layout- und Snapshot-Regression
- bei der funktionalen Korrektur gemäß Projektregel: `README.md`, `status.md`, `version.md` und Patch-Version synchronisieren

## Abnahmekriterien

- Live- und History-Daten sind sowohl in den Dateien als auch in der TUI getrennt.
- Ein aktiver Run ist bei 40×18 mindestens mit Hauptzeile und erstem Kontextwert sichtbar.
- History und Fußzeile bleiben sichtbar, ohne Live-Zeilen zu überschreiben.
- Zusätzliche Modelle, GPUs und ältere Run-Unterzeilen werden nur ausgeblendet, nicht über andere Bereiche gezeichnet.
- Bestehende CLI-Optionen, Exit-Codes, Collector-Schema und alte History-Dateien bleiben kompatibel.

# status.md — otop

**Version 1.10.2** · Stand 31.10.2026 · Status: Live- und History-Anzeige sowie deren Speicherung sind wieder strikt getrennt.

## Aktueller Stand

`otop.py` ist eine einzelne Python-Standardbibliotheks-Anwendung mit curses-TUI
und `--once`-Ausgabe. Die TUI zeigt die Bereiche System, GPU, Ollama und
History in dieser Reihenfolge. CPU, RAM, GPU, VRAM und Power verwenden
konsistente Balken, Abstände und eine globale Farbsyntax. Struktur ist Cyan,
Statuswerte und Temperaturen verwenden Grün/Gelb/Rot, Sekundärinfos sind
gedimmt. Ollama-Modelle zeigen einen geteilten Speicherbalken im gleichen
Raster wie die Sensoren: GPU/VRAM ist Grün oberhalb 55 %, Gelb bei 45–55 %
und Rot darunter; CPU/RAM bleibt gedimmt grau. Beide Anteile verwenden `#`.
CPU-Power wird nicht angezeigt, weil auf diesem Host keine zugängliche,
verlässliche Quelle existiert. History speichert begrenzte, datensparsame JSONL-Snapshots mit UTC-Zeitstempeln. System-Snapshots enthalten keine aktiven Runs; diese bleiben bis zum Abschluss ausschließlich in der Live-Datei und wechseln danach in die getrennte Run-History. Instrumentierte Runs enthalten optional Kontexttoken und Kontextlimit; die TUI visualisiert den Verbrauch als Balken.
Aktive Run-Metriken können über einen token-geschützten lokalen HTTP-Collector
(`POST /v1/runs`) geliefert werden. Er verwaltet mehrere parallele Runs,
dedupliziert finale Einträge nach Quelle und Run-ID und zeigt die Quelle in TUI
und Historie. Schema-1-JSONL bleibt als `legacy` lesbar. Zusätzlich instrumentieren `--chat` und `--generate` eigene direkte
Ollama-Aufrufe ohne Reverse Proxy und schreiben einen finalen Run pro Aufruf in
eine getrennte, begrenzte JSONL-Historie. Während des Streamings werden Kontextwerte geschätzt; autoritative
Ollama-Tokenmetriken werden erst aus dem finalen `done`-Objekt gespeichert. Für dieses Layout gilt eine Mindestgröße von
40×18.

## Korrektur in 1.10.2

- Das TUI-Layout reserviert History und Fußzeile vor dem Zeichnen der oberen Bereiche.
- Zeilenzähler werden nicht mehr rückwärts gesetzt; History überschreibt keine Live- oder Modellzeilen.
- Zusätzliche GPU- und Modellkarten werden bei Platzmangel ausgeblendet.
- System-Snapshots speichern kein aktives Run-Objekt mehr; alte Snapshots bleiben lesbar.
- Ein Fake-curses-Regressionstest prüft 40×18 bis 120×40 mit mehreren Live-, History-, GPU- und Modelleinträgen.

## Vorherige technische Korrekturen (1.1.0)

- `/api/ps`-Fehler werden nicht mehr gleichzeitig als „kein Modell geladen“
dargestellt.
- Nicht-numerische NVIDIA-Auslastung wird als `n/a` angezeigt statt eine
Formatierungs-Ausnahme in der TUI auszulösen.
- Ein nicht erfolgreicher `nvidia-smi`-Prozess liefert keine scheinbaren
Messwerte; bei fehlenden NVIDIA-Daten erfolgt der sysfs-Fallback.
- `--no-nvidia` verwendet sysfs und behält dort AMD- und Intel-Geräte bei.
Mehrere NVIDIA-Geräte werden nicht mehr verworfen.
- VRAM-Werte werden intern einheitlich in MiB ausgegeben: `nvidia-smi` liefert
bereits MiB, sysfs-Werte werden von Bytes umgerechnet.
- CPU-Auslastung wird pro Refresh-Intervall berechnet.
- VRAM- und Power-Zeilen erscheinen in TUI und `--once`; der Hilfe-Dialog zeigt
nun auch seinen Text.
- Docstring und Projektdokumentation verweisen nur auf tatsächlich verwendete
Ollama-Endpunkte beziehungsweise vorhandene Dateien.

Der normale TUI-Start prüft den Open-WebUI-Adapterstatus. Mit dem expliziten
Opt-in `OTOP_OPEN_WEBUI_AUTO_INSTALL=1` wird der Adapter automatisch installiert
oder aktualisiert; `--once` bleibt ohne administrative Änderungen.

## Weiterhin bekannte Grenzen

- Der Kontextbalken verwendet Prompt- plus Ausgabetoken. Das Limit stammt aus `options.num_ctx` oder wird für passende Runs aus `context_length` des aktuell geladenen Modells in `/api/ps` übernommen. Während Open-WebUI streamt, wird der Verbrauch sichtbar als `≈ geschätzt` aus Request- und Stream-Zeichen berechnet. Ein serverseitiger KV-Cache und nicht gestreamtes Thinking bleiben unsichtbar; finale Providerwerte ersetzen deshalb immer die Schätzung.

- GPU-Auslastung ist geräteweit und nicht exklusiv Ollama zurechenbar.
- `nvidia-smi` und sysfs werden als Fallback, nicht parallel, abgefragt.
- Bei wenig Terminalplatz werden zusätzliche GPU-/Modellkarten und ältere
  Run-Unterzeilen ausgeblendet; kein Scroll-Modus.
- Power-Limits sind nur verfügbar, wenn die jeweilige Quelle sie meldet.
- Langsame HTTP- oder `nvidia-smi`-Abfragen blockieren derzeit kurzzeitig die
  TUI-Eingabe; eine Entkopplung ist eine spätere technische Verbesserung.
- Die TUI arbeitet weiterhin synchron; langsame API- oder Sensorabfragen können
  kurzzeitig die Eingabe blockieren.
- Git ist im Projektverzeichnis initialisiert; Branch `master`, erster Commit
  steht noch aus.
- Der direkte Client-Modus instrumentiert nur Aufrufe, die über `otop` selbst
  erfolgen; fremde Ollama-Clients bleiben ohne Adapter unsichtbar.
- Der Open-WebUI-Adapter wird mit `--install-open-webui-adapter` per Admin-API
  installiert, konfiguriert und global aktiviert. Dafür muss ausschließlich
  `OPEN_WEBUI_API_KEY` in der lokalen otop-`.env` gesetzt sein. Der Pi-Adapter
  ist weiterhin offen.

## Prüfung am 31.10.2026

- `python3 -m py_compile otop.py`: OK.
- `python3 otop.py --version`: `otop 1.6.1`.
- `python3 otop.py --once` und `--once --no-nvidia`: OK.
- Mock-Rendering: 0/100-, 44/56-, 50/50-, 56/44-, 100/0- und fehlende
  Speichergrößen nutzen erwartete Segmentbreiten, Offload-Farben,
  Übergangsmarker sowie gedimmtes `n/a`: OK.
- Pseudo-TTY mit Beenden: OK.
- Git-Repository: initialisiert, Arbeitsbaum vor dem ersten Commit ungeordnet.
- Open-WebUI-Filtertest: Start, finaler Stream-Chunk, Outlet-Deduplizierung,
  parallele Metadaten-Schlüssel und datensparsame Ereignisse: OK.
- Container-Netz geprüft: `open-webui` nutzt `ai-net`, Gateway `172.18.0.1`.
- API-Installation mit lokalem Admin-Key: Filter `otop_run_metrics` erfolgreich
  angelegt, Valves gesetzt sowie aktiv und global geschaltet.
- Live-Chat über `/api/chat/completions` mit `qwen3.5:4b`: HTTP 200, ein
  finaler `open-webui`-Run mit Prompt- und Ausgabe-Token in `runs.jsonl`.
  Die von Open WebUI durchgereichte finale Datenform enthielt keine
  Gesamtdauer; sie bleibt erwartungsgemäß `n/a`.
- Collector-Test mit `started` und `completed`: HTTP 202, aktiver Run entfernt,
  finaler Schema-2-Eintrag inklusive Quelle und umgerechneter Dauern gespeichert.
- Direkter Live-Test: `--chat` gegen `qwen3.5:4b` lieferte finale
  `prompt_eval_count`, `eval_count` sowie Dauerwerte; der Abschlusslauf wurde
  in `runs.jsonl` geschrieben.

Eine visuelle Kontrolle in einem echten interaktiven Terminal bleibt sinnvoll.

## Historischer Zwischenstand der Live-Kontextschätzung (1.10.0)

- Standardbibliotheks-Tests im Session-Scratch: Promptmessung ohne Bilddaten/IDs,
  native Deltas, kumulative Snapshots, Thinking, OpenAI-Choices und Null-Usage.
- Collector: Startschätzung, Faktorlernen, geringere Abweichung im kontrollierten
  Wiederholungstest, Final-Deduplizierung, Abbruch-/Partial-Ausschluss, parallele
  Ereignisse, private Dateirechte und keine Text-/Zeichenzählerpersistenz geprüft.
- Lokaler HTTP-Test: authentifiziert 202, ohne Token 401.
- Adapter-Hooks mit Pydantic-Teststub, Collector-Ausfall und direkter Client mit
  Mock-Stream geprüft. Keine Installation zusätzlicher Software.
- Mock-TUI 40×18 mit mehreren GPUs, Modellen und Runs: erster Kontextwert samt
  Qualitätsmarker, History und Fußzeile bleiben sichtbar.

Damals offen (in 1.10.1 unten geprüft): echte Open-WebUI-/Ollama-Messreihe mit Fließtext, Deutsch, Code, JSON und
Thinking; bessere mittlere Genauigkeit ist bislang nur synthetisch nachgewiesen.
Die installierte Open-WebUI-Filterversion wurde nicht administrativ verändert.
Hook-Reihenfolge/Requestvollständigkeit, unsichtbares Thinking, Toolloops und
sequenzlose identische Deltas bleiben live zu prüfen. Quellenübergreifende
Ersatzfaktoren werden bewusst nicht gelernt: ohne Modellfaktor gilt 4,0.
In 1.10.0 war die Kalibrierung nur pro Prozess serialisiert; 1.10.1 ergänzt `flock`.

Abschlussprüfungen (Scratch-Kopien, isoliertes `XDG_STATE_HOME`):
- `py_compile` für otop und Adapter: OK.
- `--version`: `otop 1.10.0`, Exit 0.
- `--once` und `--once --no-nvidia`: Exit 0.
- Vorhandener Metriktest: OK mit ausschließlich im Scratch auf `≈ geschätzt`
  angepasster alter Erwartung `≈ estimated`; Projekt-Testdatei unverändert.
- Zusätzliche Sequenz-Deduplizierung, Toolcall-Partial und Zeichenmessung für
  Deutsch, Fließtext, Code und JSON: OK (synthetisch, keine Provider-Benchmarks).

## Live-Abnahme und Abschluss — 1.10.1

**Umgebung:** Ollama 0.40.6, Open WebUI 0.12.3, Modell `qwen3.5:4b`, Temperatur 0,
Kontextlimit 4096, maximal 220 Ausgabetoken für die Vergleichsreihe. Alle lokalen
Test-Historien, Kalibrierungen und Messprotokolle lagen im Session-Scratch;
keine Testevents wurden an die normale Run-History geschickt. Eigene Collector-
Testserver nutzten Port 11436 und wurden danach beendet. Keine Software installiert.

### Tatsächlich ausgeführt

- Abschließende Messreihe: 24 erfasste Runs (darunter ein Abbruch), zusätzlich
  zwei parallele Open-WebUI-Requests und ein erfolgreicher Chat bei abgeschaltetem
  Test-Collector. Zehn direkte und fünf Open-WebUI-Vergleichsruns deckten Prosa,
  Deutsch, Code, JSON und Thinking ab. Livewerte änderten sich vor dem Finalchunk;
  finale Zähler/Schätzabweichungen wurden in der isolierten History geprüft.
- Sechs gleichartige Open-WebUI-Prosa-Runs einschließlich unkalibriertem Start:
  anschließend fünf kalibrierte Wiederholungen, jeweils sechs sichtbare Updates.
- Native Toolrunde mit echtem vom Modell gewähltem `get_weather`-Aufruf und
  anschließend eingespeistem Test-Toolresultat. Zusätzlicher finaler Open-WebUI-
  Test ebenfalls mit tatsächlichem Toolaufruf plus Resultat: zwei getrennte
  Abschlüsse, Toolausgabe korrekt `estimate_partial`, keine Textpersistenz.
- Open-WebUI-HTTP-Abbruch nach zwölf Chunks: `cancelled`, keine erfundenen
  finalen Zähler, Kalibrierung unverändert. Direkter `--chat`-SIGINT: ebenso.
- `--generate` real ausgeführt: 59 Chunks, autoritative finale Kontexttoken.
- Zwei parallele Open-WebUI-Requests und zwei parallele direkte Clientprozesse:
  jeweils zwei eigene finale Runs, keine verlorenen History-Einträge.
- Reale curses-Sitzungen über PTY in **40×18** und **120×40** mit Live-Sensoren:
  Kontext, `≈`, Qualitätsstatus, History, Fußzeile und Beenden per `q` geprüft;
  große Ansicht zeigt zusätzlich die Abweichungsdiagnose. Kein menschlicher
  Screenshot-/Sichttest behauptet.
- Finale Live-Dateien auf private Rechte 0600 und Abwesenheit von Prompt-/Antwort-
  text sowie temporären `prompt_chars`/`output_chars` geprüft.
- Adapter **1.3.1** über die bestehende Admin-API aktualisiert, aktiv/global belassen.
  Nach den Tests gewöhnlichen Collector-Endpunkt und übrige Valves wiederhergestellt;
  Priorität 1000 lässt die Requestmessung nach gewöhnlichen Filtern laufen.
  Die bereits laufende otop-Instanz wurde nicht beendet oder manipuliert.

### Gemessene Genauigkeit — mittlere absolute Kontextabweichung

| Vergleich | Zeichen/4 | Kalibriert |
|---|---:|---:|
| Fünf gleichartige Wiederholungen nach erstem Prosa-Run | 38,22 % | 16,94 % |
| Letzte dieser fünf Wiederholungen | 38,22 % | 9,09 % |
| Abschließende gemischte Zehnerreihe (nach Prosa-Wiederholungen) | 18,51 % | 18,15 % |
| Frühere gemischte Zehnerreihe (ohne diese Wiederholungen) | 18,51 % | 19,27 % |

Der Verbesserungseffekt ist text- und reihenfolgeabhängig. Ein einziger Modellfaktor
kann bei wechselnden Sprachen/Formaten zeitweise schlechter als Zeichen/4 sein.
Die Messreihe ist klein und kein allgemeiner Genauigkeitsnachweis. Startwert 4,0,
Schutzbereich 0,5–12 und 80/20-Glättung wurden nicht nachträglich auf diese Daten
optimiert. Unsichtbares Thinking ohne gemeldeten Zähler, unbekannte Hookformen und
Requesttransformationen nach dem Filter bleiben prinzipielle Beobachtungsgrenzen.
Keine Prompts/Antworten oder rohen Zeichenzähler wurden in Projektberichte übernommen.

### Regression und verbleibender Bedienhinweis

- Fünf persistente Testgruppen in `test_otop.py`: Zeichenmessung/Streamformen,
  Kalibrierung/Datenschutz, Parallelität, Adapter-Runden/Abbruch sowie bestehende
  Anzeigeprüfungen. Aus Scratch-Kopien ohne zusätzliche Abhängigkeiten ausgeführt.
- Alte Schema-1/2-Ereignisse bleiben lesbar; keine CLI-/Exit-Code-Umbenennungen.
- Eine vor dem Update gestartete TUI bitte mit **`r`** neu laden. Der neu installierte
  Filter bleibt mit älteren Collectoren kompatibel; Kalibrierung erfordert den neuen
  otop-Code im tatsächlich laufenden Prozess.

Abschließende Wiederholungsprüfung des fertigen Stands:
- `py_compile` für Anwendung, Adapter und Testdatei: OK (Bytecode nur im Scratch).
- `python3 test_otop.py` aus Scratch-Kopie: **5 Testgruppen OK**, einschließlich
  Schema-1/2-Kompatibilität, Modellwechsel, ungültigen Zählern und HTTP 401/202.
- `--version`: **otop 1.10.1**, Exit 0.
- `--once` und `--once --no-nvidia`: jeweils Exit 0, isolierte State-Dateien.
- Installierter Adapter gegen lokalen Quelltext verglichen: **aktiv**.
- Normaler Collector-Port 11435 wiederhergestellt; Testport 11436 geschlossen.

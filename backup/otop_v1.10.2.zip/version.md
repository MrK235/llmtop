# Versionsgeschichte — otop

## Schema

`VERSION = "X.Y.Z"` in `otop.py` ist die maßgebliche Versionsquelle. Bei einem
Release werden diese Datei, `README.md` und `status.md` auf denselben Stand
gebracht.

- **Patch** (`X.Y.Z+1`): Fehlerkorrekturen ohne neue Bedienfunktion.
- **Minor** (`X.Y+1.0`): neue, abwärtskompatible Anzeige- oder CLI-Funktion.
- **Major**: inkompatible Bedien- oder Schnittstellenänderung.

## Changelog

### 1.10.2 — 31.10.2026

- Live-Runs aus System-Snapshots entfernt; Live-Datei, Run-History und System-History sind wieder getrennt.
- TUI reserviert History und Fußzeile vorab und setzt den Zeilenzähler nicht mehr auf bereits belegte Zeilen zurück.
- Bei kleinen Terminals werden zusätzliche GPU- und Modellkarten ausgeblendet, statt Live-Anzeige oder History zu überschreiben.
- Layout-Regressionstest für 40×18 bis 120×40 sowie Kompatibilität alter Snapshots ergänzt.

### 1.10.1 — 31.10.2026

- Live-Abnahme der Kontextschätzung mit Ollama 0.40.6 / Open WebUI 0.12.3
  abgeschlossen; Fließtext, Deutsch, Code, JSON, Thinking und echte Toolrunden.
- OpenAI-kompatible finale Usage schließt Provider-Runden unmittelbar ab;
  Request-Zuordnung trennt parallele API-Aufrufe, Disconnects werden abgebrochen.
- Gemischte Deltas/Snapshots, verstecktes gemeldetes Thinking, Null-Usage und
  alte Chat-/Toolmetriken abgesichert; kleine Prompts erhalten eine Startschätzung.
- Prozessübergreifende State-Sperre ergänzt; ungültige/rückläufige Zähler und
  Modellwechsel innerhalb eines Runs können die Kalibrierung nicht verfälschen.
- Direkter SIGINT wird als `cancelled` gespeichert. History bleibt bei 40×18
  sichtbar; breite Terminals zeigen die Schätzdiagnose als eigene Zeile.
- Bestehende Testdatei um fünf Standardbibliotheks-Testgruppen erweitert;
  Tests nur aus isolierten Scratch-Kopien ausgeführt. Adapter auf 1.3.1 aktualisiert.
- Reale Genauigkeitsgrenzen dokumentiert; keine Überanpassung der Startfaktoren.

### 1.10.0 — 31.10.2026

- Promptschätzung beim Start und Live-Schätzung für direkte Ollama-Aufrufe ergänzt.
- Thinking, OpenAI-Deltas, kumulative Inhalte und Sequenz-Deduplizierung unterstützt;
  Medien/IDs nicht mehr als Prompttext gezählt, unvollständige Messungen markiert.
- Modellbezogene Prompt-/Ausgabekalibrierung zentral im Collector, begrenzter
  privater Faktorspeicher und finale Schätzabweichung ergänzt.
- Collector-Schreibvorgänge innerhalb eines Prozesses serialisiert; doppelte
  Finalevents lernen nicht erneut. Abbrüche und partielle Messungen ausgeschlossen.
- Deutsche Qualitätsmarker, durchgängige Näherungskennzeichnung, Kontextfarben
  bei 70/90 % und Platzreservierung für Run/History bei kleinen Terminals.
- Reale Genauigkeitsmessung und Prüfung des installierten Filters bleiben offen.

### 1.9.0 — 31.10.2026

- Open-WebUI-Adapterstatus wird beim normalen TUI-Start geprüft und angezeigt.
- Optionales `OTOP_OPEN_WEBUI_AUTO_INSTALL=1` installiert oder aktualisiert den Adapter beim TUI-Start.
- `--once` führt weiterhin keine administrativen Open-WebUI-Änderungen aus.

### 1.8.0 — 31.10.2026

- Live-Kontextschätzung für Open-WebUI-Streams aus Request- und Antwortzeichen ergänzt.
- Geschätzte Werte werden mit `≈ geschätzt` gekennzeichnet und durch finale Providerwerte ersetzt.
- Streamupdates auf maximal vier pro Sekunde begrenzt; Prompts und Antworten werden nicht persistiert.

### 1.7.0 — 31.10.2026

- Kontextverbrauch instrumentierter Runs aus Prompt- und Ausgabetoken als Balken dargestellt.
- Kontextlimit aus Run-Request (`options.num_ctx`) und optionalen Schema-2-Feldern historisiert.
- Fehlende Limits werden bei passendem Modell aus Ollamas `/api/ps` (`context_length`) ergänzt und in der Run-History nachgetragen.
- Kontextmetrik bleibt datensparsam und verwendet keine Prompt- oder Antwortinhalte.

### 1.6.1 — 31.10.2026

- Open-WebUI-Adapterinstallation über die Admin-API ergänzt.
- API-Valves korrekt als direkter Request-Body übertragen; bestehende Aktivierungs-
  und Globalzustände bleiben bei Updates erhalten.
- Alte Einzelrun- und Kontextanzeige-Hilfen entfernt; Filter instrumentiert nur
  noch eindeutig als Ollama erkannte Provider.

### 1.6.0 — 31.10.2026

- Open-WebUI-Filteradapter für datensparsame Ollama-Runmetriken ergänzt.
- Collector-Bind-Adresse und Port für private Docker-Netze konfigurierbar gemacht;
  sicherer Loopback-Default bleibt erhalten.
- Token-geschützten lokalen Collector für Schema-2-Runereignisse ergänzt.
- Mehrere parallele aktive Runs, Quellenlabels und Deduplizierung nach Quelle
  und Run-ID ergänzt; Schema-1-Einträge bleiben als `legacy` lesbar.
- Generischen Testsender `--emit` und lokale `.env`-Konfiguration ergänzt.

### 1.5.0 — 31.10.2026

- Direkten opt-in-Clientmodus `--chat` und `--generate` ergänzt; er ruft
  Ollama ohne Reverse Proxy auf und zeichnet ausschließlich eigene Runs auf.
- Finale Ollama-Metriken werden aus dem `done`-Objekt übernommen, von
  Nanosekunden in Sekunden umgerechnet und als begrenzte, deduplizierte
  `runs.jsonl` gespeichert.
- History zeigt die letzten abgeschlossenen instrumentierten Runs; System-
  Snapshots bleiben getrennt erhalten.

### 1.4.1 — 31.10.2026

- Ollama-Bereich in „Aktueller Run“ und „Geladene Modelle“ geteilt.
- Optionalen JSONL-Run-Eingang über `OTOP_RUN_FILE` ergänzt.
- Kontextbalken, Prompt-/Ausgabe-/Gesamttoken und Ausgabe-Rate ergänzt.
- Nicht instrumentierte oder veraltete Runs werden eindeutig angezeigt.

### 1.4.0 — 31.10.2026

- Lokale, begrenzte JSONL-History mit UTC-Zeitstempeln, atomischem Schreiben
  und tolerierter Beschädigung einzelner Zeilen ergänzt.
- Snapshot-Schema für Ollama-, System-, GPU- und Fehlerdaten eingeführt.
- History-Pfad über `OTOP_HISTORY_FILE` beziehungsweise `XDG_STATE_HOME`
  konfigurierbar; Standardpfad ist `~/.local/state/otop/history.jsonl`.

### 1.3.5 — 31.10.2026

- Hostwerte aus `OLLAMA_HOST` und `--host` werden zuverlässig normalisiert.
- JSON-Antworten und `/api/ps`-Modelllisten werden validiert.
- CSV-Ausgaben von `nvidia-smi` werden robust geparst; Prozentwerte und
  Modell-Offload bleiben innerhalb sinnvoller Grenzen.

### 1.3.4 — 31.10.2026

- Ollama-Speicherfarben bewerten den Offload-Grad der GPU/VRAM-Anzeige: Grün
  oberhalb 55 %, Gelb bei 45–55 % und Rot unterhalb 45 % GPU-Anteil.
- CPU/RAM bleibt gedimmt grau; Rahmen und Label des Speicherbalkens bleiben
  Cyan, fehlende Größen gedimmt als `GPU/CPU n/a`.

### 1.3.3 — 31.10.2026

- Globale Farbrollen für Struktur, Status, GPU-/CPU-Speicher, Sekundärtext
  und Fehler eingeführt.
- Ollama-Speicherbalken an Sensorgeometrie angepasst; GPU und CPU sind mit
  durchgehenden, unterschiedlich gefärbten `#`-Segmenten dargestellt.

### 1.3.2 — 31.10.2026

- Modellname, „Speicher“, Balkenklammern und GPU-Anteil im Ollama-Bereich
  konsequent Cyan dargestellt.
- `r` / `R` startet das Programm nach sauberem curses-Cleanup mit denselben
  Kommandozeilenoptionen neu.

### 1.3.0 — 31.10.2026

- CPU- und GPU-Temperatursensoren ergänzt, inklusive farbiger Textanzeige und
  sysfs-/NVIDIA-Quellen.
- Ollama-Modelle mit hervorgehobenem Namen, gedimmten Metadaten und geteiltem
  GPU-/CPU-Speicherbalken dargestellt.
- Mindesthöhe auf 40×20 angepasst, um zusätzliche Temperaturzeilen zu sichern.

### 1.2.3 — 31.10.2026

- GPU-Power-Balken auf mindestens 115 W Boost-Skala vereinheitlicht; höhere
  gemeldete Grenzen bleiben maßgeblich.
- Leerzeilen zwischen System, GPU, Ollama und History ergänzt; Mindesthöhe auf
  40×18 angepasst.
- CPU-Power nicht ergänzt: Auf dem Zielhost existiert keine zugängliche,
  verlässliche Datenquelle.

### 1.2.2 — 31.10.2026

- GPU-Poweranzeige verwendet bei NVIDIA die effektive Leistungsgrenze als
  Fallback und liest im sysfs-Pfad eine vorhandene Power-Cap.
- Ohne Leistungsgrenze wird die tatsächliche Leistung in Watt als primärer
  Sensorwert statt als gedimmtes Detail hinter `n/a` angezeigt.

### 1.2.1 — 31.10.2026

- Mindesthöhe der Vierbereiche-TUI von 8 auf 14 Zeilen angehoben, damit die
  feste Fußzeile keine Bereichsinhalte überdeckt.

### 1.2.0 — 31.10.2026

- TUI als vierteilige, htop/glances-orientierte Ansicht strukturiert:
  System, GPU, Ollama und History.
- Sensorzeilen für CPU, RAM, GPU, VRAM und Power mit einheitlicher
  Balkenbreite, ausgerichteten Werten und Ampelfarben versehen.
- History als visuellen, gedimmten Platzhalter vorbereitet; keine Speicherung
  oder neue Bedienfunktion.

### 1.1.0 — 31.10.2026

- GPU-Erfassung stabilisiert: Rückgabecode von `nvidia-smi`, sysfs-Fallback,
  mehrere NVIDIA-Geräte und `--no-nvidia` funktionieren konsistent.
- VRAM-Werte auf MiB vereinheitlicht; VRAM- und Power-Anzeige in TUI sowie
  Einzel-Snapshot ergänzt.
- TUI gegen nicht-numerische GPU-Auslastung abgesichert, CPU-Intervallmessung
  korrigiert und Hilfe-Text sichtbar gemacht.
- Fehler von `/api/ps` eindeutig angezeigt.
- README, Status und Code-Docstring bereinigt.

### 1.0.0 — Ausgangsversion

- Ollama-Modellstatus, CPU-, RAM- und GPU-Anzeige in einer curses-TUI.
- Optionen `--host`, `--interval`, `--once`, `--no-nvidia` und `--version`.

## Release-Checkliste

1. `python3 -m py_compile otop.py` ausführen.
2. `python3 otop.py --version`, `--once` und `--once --no-nvidia` prüfen.
3. TUI in einem echten Terminal sowie Fehlerfälle mit Mock-Ollama prüfen.
4. Dokumentation und `VERSION` abgleichen.

"""
title: otop Run Metrics
author: otop
version: 1.3.1
required_open_webui_version: 0.12.3
description: Meldet datensparsame Ollama-Runmetriken an den lokalen otop-Collector.
"""

import asyncio
import json
import math
import os
import time
import urllib.error
import urllib.request
import uuid
from collections import defaultdict, deque
from datetime import datetime, timezone
from typing import Any, Optional

from pydantic import BaseModel, Field


FINAL_FIELDS = {
    "prompt_eval_count",
    "eval_count",
    "load_duration",
    "prompt_eval_duration",
    "eval_duration",
    "total_duration",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def number(value: Any) -> Optional[float]:
    return value if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0 else None


def measure_prompt(body):
    """Zählt ausschließlich Kontexttext; Medien und unbekannte Inhalte sind partiell."""
    partial = False

    def content(value):
        nonlocal partial
        if isinstance(value, str):
            if value.startswith("data:"):
                partial = True
                return 0
            return len(value)
        if isinstance(value, list):
            return sum(content(item) for item in value)
        if isinstance(value, dict):
            if value.get("type") in ("text", "input_text", "output_text"):
                return content(value.get("text"))
            partial = True
        return 0

    total = sum(content(body.get(key)) for key in ("system", "prompt", "suffix"))
    for message in body.get("messages", []):
        if not isinstance(message, dict):
            partial = True
            continue
        total += sum(content(message.get(key)) for key in ("content", "thinking", "reasoning_content"))
        for call in message.get("tool_calls", []) or []:
            function = call.get("function", {}) if isinstance(call, dict) else {}
            total += len(json.dumps(function, ensure_ascii=False, separators=(",", ":")))
        partial |= bool(message.get("images") or message.get("files"))
    if body.get("tools"):
        total += len(json.dumps(body["tools"], ensure_ascii=False, separators=(",", ":")))
    partial |= bool(body.get("images") or body.get("files"))
    return total, partial


def estimate_messages(body):
    return measure_prompt(body)[0]


def count_stream(run, event):
    """Native/choice-Deltas addieren, explizite Snapshots kanalweise deduplizieren.

    Identische Deltas ohne Sequenz-ID sind nicht von echter Wiederholung
    unterscheidbar und werden daher nicht stillschweigend verworfen.
    """
    sequence = event.get("sequence_id", event.get("sequence"))
    if isinstance(sequence, (str, int)) and not isinstance(sequence, bool):
        seen = run.setdefault("seen_sequences", [])
        if sequence in seen:
            return
        seen.append(sequence)
        del seen[:-256]
    chunks = []
    if isinstance(event.get("choices"), list):
        for choice in event["choices"]:
            if isinstance(choice, dict):
                chunks.append((str(choice.get("index", 0)), choice.get("delta") or choice.get("message") or {},
                               "delta" not in choice))
    elif isinstance(event.get("message"), dict):
        chunks.append(("0", event["message"], "done" not in event))
    else:
        chunks.append(("0", event, "done" not in event and "response" not in event))
    states = run.setdefault("stream_states", {})
    for channel, chunk, cumulative in chunks:
        if not isinstance(chunk, dict):
            continue
        for field in ("content", "response", "thinking", "reasoning_content", "text"):
            text = chunk.get(field)
            if not isinstance(text, str):
                continue
            key = channel + ":" + field
            previous = states.get(key, "")
            if cumulative:
                if text.startswith(previous):
                    run["stream_chars"] += len(text) - len(previous)
                else:
                    run["output_partial"] = True
                states[key] = text
            else:
                run["stream_chars"] += len(text)
                states[key] = previous + text
            if field in ("thinking", "reasoning_content") and text:
                run["thinking_seen"] = True
        if chunk.get("tool_calls"):
            run["output_partial"] = True



def find_metrics(value: Any) -> Optional[dict]:
    """Sucht nur bekannte Nutzungsfelder; Textinhalte werden nie übernommen."""
    if isinstance(value, dict):
        if value.get("done") is True or FINAL_FIELDS.intersection(value):
            result = {key: value[key] for key in FINAL_FIELDS if number(value.get(key)) is not None}
            if isinstance(value.get("done_reason"), str):
                result["status_detail"] = value["done_reason"]
            if result:
                return result
        usage = value.get("usage")
        if isinstance(usage, dict):
            result = {}
            prompt = number(next((usage[k] for k in ("input_tokens", "prompt_tokens", "prompt_eval_count") if number(usage.get(k)) is not None), None))
            output = number(next((usage[k] for k in ("output_tokens", "completion_tokens", "eval_count") if number(usage.get(k)) is not None), None))
            if prompt is not None:
                result["prompt_tokens"] = prompt
            if output is not None:
                result["output_tokens"] = output
            for source, target in (("total_duration", "total_duration"),
                                   ("total_time", "total_duration"),
                                   ("duration", "total_duration"),
                                   ("eval_duration", "eval_duration"),
                                   ("completion_duration", "eval_duration"),
                                   ("response_token/s", "output_rate"),
                                   ("response_tokens_per_second", "output_rate")):
                duration = number(usage.get(source))
                if duration is not None:
                    result[target] = duration
            if result:
                return result
        # Only provider envelopes, never arbitrary tool arguments or earlier chat usage.
        for key in ("data", "response", "message", "choices", "messages"):
            child = value.get(key)
            if key == "messages" and isinstance(child, list):
                child = child[-1] if child else None
            result = find_metrics(child)
            if result is not None:
                return result
        if value.get("done") is True:
            return {}
    elif isinstance(value, list):
        for child in reversed(value):
            result = find_metrics(child)
            if result is not None:
                return result
    return None


class Filter:
    class Valves(BaseModel):
        priority: int = 1000
        collector_url: str = Field(default_factory=lambda: os.getenv("OTOP_COLLECTOR_URL", "http://172.18.0.1:11435"))
        collector_token: str = Field(default_factory=lambda: os.getenv("OTOP_COLLECTOR_TOKEN", ""))
        ollama_base_url: str = Field(default_factory=lambda: os.getenv("OLLAMA_BASE_URL", "http://ollama:11434"))
        timeout_seconds: float = 0.5
        stale_seconds: float = 900.0

    def __init__(self):
        self.valves = self.Valves()
        self._runs: dict[str, deque[dict]] = defaultdict(deque)
        self._lock = asyncio.Lock()

    def _is_ollama(self, _body: dict, model: Optional[dict]) -> bool:
        """Ohne verifizierten Provider nie instrumentieren."""
        if not isinstance(model, dict):
            return False
        owned_by = str(model.get("owned_by", "")).lower()
        base_url = str(model.get("base_url", ""))
        return (owned_by == "ollama" or
                base_url.rstrip("/") == self.valves.ollama_base_url.rstrip("/"))

    @staticmethod
    def _key(model: str, metadata: Optional[dict]) -> str:
        metadata = metadata or {}
        stable = metadata.get("message_id") or metadata.get("chat_id") or metadata.get("session_id") or "api"
        return f"{stable}:{model}"

    @staticmethod
    def _metadata(metadata, request):
        metadata = dict(metadata or {})
        if request is not None:
            metadata["message_id"] = f"request-{id(request)}:{metadata.get('message_id', '')}"
        return metadata

    def _cleanup(self) -> None:
        cutoff = time.monotonic() - max(30.0, self.valves.stale_seconds)
        for key in list(self._runs):
            for run in self._runs[key]:
                if run["created"] < cutoff and run.get("watcher"):
                    run["watcher"].cancel()
            self._runs[key] = deque(run for run in self._runs[key] if run["created"] >= cutoff)
            if not self._runs[key]:
                del self._runs[key]

    def _send_sync(self, event: dict) -> None:
        if not self.valves.collector_token or not self.valves.collector_url:
            return
        request = urllib.request.Request(
            self.valves.collector_url.rstrip("/") + "/v1/runs",
            data=json.dumps(event, separators=(",", ":")).encode("utf-8"),
            headers={
                "Authorization": "Bearer " + self.valves.collector_token,
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=max(0.05, self.valves.timeout_seconds)) as response:
                response.read(1)
        except (OSError, urllib.error.URLError, ValueError):
            pass

    async def _send(self, event: dict) -> None:
        try:
            await asyncio.wait_for(
                asyncio.to_thread(self._send_sync, event),
                timeout=max(0.1, self.valves.timeout_seconds + 0.2),
            )
        except (asyncio.TimeoutError, OSError):
            pass

    async def request(
        self,
        body: dict,
        __metadata__: Optional[dict] = None,
        __model__: Optional[dict] = None,
        __request__: Any = None,
    ) -> dict:
        __metadata__ = self._metadata(__metadata__, __request__)
        if not self._is_ollama(body, __model__):
            return body
        model = str(body.get("model") or (__model__ or {}).get("id") or "unknown")
        now = utc_now()
        run = {
            "run_id": str(uuid.uuid4()),
            "model": model,
            "started_at": now,
            "created": time.monotonic(),
            "stream_chars": 0,
            "last_update": 0.0,
        }
        run["prompt_chars"], run["prompt_partial"] = measure_prompt(body)
        options = body.get("options") if isinstance(body.get("options"), dict) else {}
        num_ctx = options.get("num_ctx")
        if isinstance(num_ctx, (int, float)) and not isinstance(num_ctx, bool) and num_ctx > 0:
            run["context_limit"] = num_ctx
            run["context_limit_source"] = "request"
        key = self._key(model, __metadata__)
        async with self._lock:
            self._cleanup()
            self._runs[key].append(run)
        if __request__ is not None and hasattr(__request__, "is_disconnected"):
            run["watcher"] = asyncio.create_task(self._watch_disconnect(key, run["run_id"], __request__))
        await self._send({
            "schema": 2,
            "event": "started",
            "run_id": run["run_id"],
            "source": "open-webui",
            "model": model,
            "started_at": now,
            "updated_at": now,
            **self._estimates(run),
            **{key: run[key] for key in ("context_limit", "context_limit_source") if key in run},
        })
        return body

    async def _watch_disconnect(self, key, run_id, request):
        try:
            while True:
                await asyncio.sleep(0.5)
                queue = self._runs.get(key, ())
                if not any(run["run_id"] == run_id for run in queue):
                    return
                if await request.is_disconnected():
                    await self._cancel_run(key, run_id)
                    return
        except (asyncio.CancelledError, RuntimeError):
            return

    async def _cancel_run(self, key, run_id):
        async with self._lock:
            queue = self._runs.get(key)
            run = next((r for r in queue or [] if r["run_id"] == run_id), None)
            if run is None:
                return
            queue.remove(run)
            if not queue:
                self._runs.pop(key, None)
        now = utc_now()
        await self._send({"schema": 2, "event": "cancelled", "source": "open-webui",
                          "run_id": run_id, "model": run["model"],
                          "started_at": run["started_at"], "updated_at": now,
                          "finished_at": now, **self._estimates(run)})

    @staticmethod
    def _estimates(run):
        prompt = max(1, round(run["prompt_chars"] / 4)) if run.get("prompt_chars") else 0
        output = max(1, round(run["stream_chars"] / 4)) if run.get("stream_chars") else 0
        result = {"prompt_chars": run.get("prompt_chars", 0),
                  "output_chars": run.get("stream_chars", 0),
                  "prompt_partial": run.get("prompt_partial", False),
                  "output_partial": run.get("output_partial", False)}
        if prompt or output:
            result.update(prompt_tokens_estimate=prompt, output_tokens_estimate=output,
                          context_tokens_estimate=prompt + output,
                          estimate_quality="partial" if result["prompt_partial"] or result["output_partial"] else "estimated")
        return result

    async def _find_run(self, model: str, metadata: Optional[dict]) -> Optional[dict]:
        key = self._key(model, metadata)
        async with self._lock:
            self._cleanup()
            queue = self._runs.get(key)
            if not queue and not any((metadata or {}).get(k) for k in ("message_id", "chat_id", "session_id")):
                candidates = [candidate for candidate in self._runs if candidate.endswith(":" + model)]
                queue = self._runs[candidates[0]] if len(candidates) == 1 else None
            return queue[0] if queue and len(queue) == 1 else None

    async def _update(self, model: str, metadata: Optional[dict], metrics: dict) -> None:
        run = await self._find_run(model, metadata)
        if not run:
            return
        changed = {key: value for key, value in metrics.items() if run.get(key) != value}
        if not changed:
            return
        run.update(changed)
        now = utc_now()
        await self._send({
            "schema": 2, "event": "updated", "run_id": run["run_id"],
            "source": "open-webui", "model": run["model"],
            "started_at": run["started_at"], "updated_at": now, **changed,
        })

    async def _complete(self, model: str, metadata: Optional[dict], metrics: Optional[dict]) -> None:
        key = self._key(model, metadata)
        async with self._lock:
            self._cleanup()
            queue = self._runs.get(key)
            if not queue and not any((metadata or {}).get(k) for k in ("message_id", "chat_id", "session_id")):
                candidates = [candidate for candidate in self._runs if candidate.endswith(":" + model)]
                queue = self._runs[candidates[0]] if len(candidates) == 1 else None
            if not queue or len(queue) != 1:
                return
            run = queue.popleft()
            watcher = run.get("watcher")
            if watcher:
                watcher.cancel()
            if not queue:
                for candidate_key, candidate_queue in list(self._runs.items()):
                    if candidate_queue is queue:
                        self._runs.pop(candidate_key, None)
                        break
        now = utc_now()
        event = {
            "schema": 2,
            "event": "completed",
            "run_id": run["run_id"],
            "source": "open-webui",
            "model": run["model"],
            "started_at": run["started_at"],
            "updated_at": now,
            "finished_at": now,
            **self._estimates(run),
            **{key: run[key] for key in ("context_limit", "context_limit_source") if key in run},
        }
        if metrics:
            event.update(metrics)
            if metrics.get("status_detail") in ("cancelled", "canceled", "error"):
                event["event"] = "error" if metrics["status_detail"] == "error" else "cancelled"
        else:
            event["event"] = "cancelled"
        await self._send(event)

    async def stream(
        self,
        event: dict,
        __metadata__: Optional[dict] = None,
        __model__: Optional[dict] = None,
        __request__: Any = None,
    ) -> dict:
        __metadata__ = self._metadata(__metadata__, __request__)
        model = str(event.get("model") or (__model__ or {}).get("id") or "unknown")
        run = await self._find_run(model, __metadata__)
        metrics = find_metrics(event)
        if event.get("error") or event.get("cancelled"):
            await self._complete(model, __metadata__, {"status_detail": "error" if event.get("error") else "cancelled"})
            return event
        if run:
            count_stream(run, event)
            usage = event.get("usage") if isinstance(event.get("usage"), dict) else {}
            details = usage.get("completion_tokens_details") or usage.get("output_tokens_details") or {}
            if isinstance(details, dict) and (number(details.get("reasoning_tokens")) or 0) > 0 and not run.get("thinking_seen"):
                run["output_partial"] = True
            now_mono = time.monotonic()
            if metrics is None and event.get("done") is not True and now_mono - run.get("last_update", 0.0) >= 0.25:
                update = self._estimates(run)
                visible = update.get("context_tokens_estimate")
                if visible != run.get("last_visible"):
                    run["last_update"] = now_mono
                    run["last_visible"] = visible
                    await self._update(model, __metadata__, update)
        choices = event.get("choices") if isinstance(event.get("choices"), list) else []
        finish = next((c.get("finish_reason") for c in choices if isinstance(c, dict) and c.get("finish_reason")), None)
        if run and finish:
            run["finish_reason"] = finish
        if metrics is not None:
            complete_usage = (any(k in metrics for k in ("prompt_tokens", "prompt_eval_count"))
                              and any(k in metrics for k in ("output_tokens", "eval_count")))
            if event.get("done") is True or event.get("done_reason") or (complete_usage and (finish or (run and run.get("finish_reason")) or "usage" in event)):
                if finish:
                    metrics["status_detail"] = finish
                await self._complete(model, __metadata__, metrics)
            else:
                await self._update(model, __metadata__, metrics)
        return event

    async def outlet(
        self,
        body: dict,
        __metadata__: Optional[dict] = None,
        __model__: Optional[dict] = None,
        __request__: Any = None,
    ) -> dict:
        __metadata__ = self._metadata(__metadata__, __request__)
        model = str(body.get("model") or (__model__ or {}).get("id") or "unknown")
        metrics = find_metrics(body)
        run = await self._find_run(model, __metadata__)
        if run:
            messages = body.get("messages", [])
            if messages and isinstance(messages[-1], dict) and messages[-1].get("role") == "assistant":
                chars, partial = measure_prompt({"messages": [messages[-1]]})
                if partial or chars > run["stream_chars"]:
                    run["output_partial"] = True
        if run and not metrics:
            metrics = {key: run[key] for key in (
                "prompt_eval_count", "eval_count", "prompt_tokens", "output_tokens", "total_duration", "eval_duration",
                "prompt_eval_duration", "load_duration") if key in run}
        await self._complete(model, __metadata__, metrics)
        return body

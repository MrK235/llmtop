import importlib.util

spec = importlib.util.spec_from_file_location('otop', 'otop.py')
otop = importlib.util.module_from_spec(spec)
spec.loader.exec_module(otop)


def test_run_metric_detail():
    assert otop.run_metric_detail({}) == 'Tokens: warten auf Provider · Tok/s: n/a'
    text = otop.run_metric_detail({'prompt_tokens': 1000, 'output_tokens': 250,
                                   'eval_duration_s': 5})
    assert text == 'Tokens: 1.2k (Prompt 1.0k, Ausgabe 250) · 50.0 Tok/s'
    text = otop.run_metric_detail({'prompt_tokens': 10, 'output_tokens': 3})
    assert text == 'Tokens: 13 (Prompt 10, Ausgabe 3) · Tok/s: n/a'
    assert 'Prompt n/a' in otop.run_metric_detail({'output_tokens': 3})


if __name__ == '__main__':
    test_run_metric_detail()
    print('OK')

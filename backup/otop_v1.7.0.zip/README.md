# otop — Ollama Terminal Monitor mit GPU-, RAM- und VRAM-Sensoren

**Version 1.7.0 · Single-File-Terminal-Anwendung (nur Python-Standardbibliothek),
die über die Ollama-API das **geladene Modell** sowie **CPU-/RAM/GPU-Auslastung**
anzeigt. Versionsgeschichte und Versionsschema: `version.md`.

Die Version wird angezeigt: in der TUI-Kopfzeile (`otop 1.6.1 • Ollama …`), in der
ersten Zeile von `--once`, und über `--version`. Maßgebliche Zahl ist `VERSION`
in `otop.py`.

## Dateien

| Datei | Inhalt |
|-------|--------|
| `otop.py` | die Anwendung (einzige Code-Datei) |
| `README.md` | diese Anleitung |
| `status.md` | Projektstand, bekannte Grenzen und Prüfhinweise |
| `version.md` | Versionsschema, Versionsanzeige, Changelog |
| `.gitignore` | lokale Python-Artefakte ausschließen |
| `plan/` | akzeptierte Arbeitspläne (Plan-Mode-Artefakte) |

## Versionierung

Das Projekt ist als Git-Repository eingerichtet. Der aktuelle Branch ist
`master`; ein erster Commit steht noch aus. Code, Dokumentation und akzeptierte
Pläne werden gemeinsam versioniert. Vor einem Commit: Tests aus `status.md`
ausführen, `VERSION` sowie `README.md`, `status.md` und `version.md` abgleichen.
Tags verwenden das Format `vX.Y.Z`.

## Start

```bash
python3 otop.py                      # Vollbild-TUI (curses), Refresh alle 2 s
python3 otop.py --interval 1         # TUI mit 1 s Refresh
python3 otop.py --once               # ein Einzel-Snapshot (Skripte / kein Terminal)
python3 otop.py --host http://127.0.0.1:11434
python3 otop.py --chat '{"model":"qwen3.5:4b","messages":[{"role":"user","content":"Hallo"}]}'
python3 otop.py --collector          # Loopback und privates Open-WebUI-Docker-Gateway
python3 otop.py --install-open-webui-adapter  # Filter per Open-WebUI-API installieren
python3 otop.py --emit event.json    # Schema-2-Testevent an den Collector senden
python3 otop.py --no-nvidia          # nvidia-smi überspringen (sysfs-Pfad)
python3 otop.py --version            # Versionsnummer, danach Exit 0 (kein TUI)
```

`$OLLAMA_HOST` wird als Default übernommen; `--host` ohne Protokoll wird zu
`http://<host>`. Für einen optionalen, ausschließlich lesenden Open-WebUI-
Datenbank-Fallback kann `OTOP_OPEN_WEBUI_DB` auf einen zugänglichen Pfad zu
`webui.db` gesetzt werden. Ohne stabile Zuordnung werden keine Daten ergänzt.

| Option | Verhalten |
|--------|-----------|
| `--host` | Ollama-URL; Default `$OLLAMA_HOST`, sonst `http://localhost:11434` |
| `--interval` | Refresh-Sekunden im TUI; Default 2 s, **auf 0.5–60 s begrenzt** (`--interval 0.1` → 0.5 s) |
| `--once` | ein Snapshot, kein Vollbild; ignoriert `--interval` (CPU-Messung 1 s) |
| `--no-nvidia` | `nvidia-smi` nicht aufrufen, sysfs benutzen |
| `--chat JSON` | direkter Streaming-Aufruf an `/api/chat`, Abschlussmetriken lokal speichern |
| `--generate JSON` | direkter Streaming-Aufruf an `/api/generate`, Abschlussmetriken lokal speichern |
| `--collector` | lokalen, token-geschützten Collector für `POST /v1/runs` starten |
| `--collector-bind` / `--collector-port` | Listen-Adresse und Port; Default bleibt `127.0.0.1:11435` |
| `--emit DATEI` | Schema-2-Event aus Datei oder `-` für stdin an den Collector senden |
| `--install-open-webui-adapter` | Filter per Open-WebUI-Admin-API installieren, konfigurieren und global aktivieren |
| `--version` | Versionsnummer ausgeben und beenden |

## Exit-Codes

| Fall | Code |
|------|------|
| normal (`--once`, TUI mit `q`) | 0 |
| kein TTY (Vollbild ohne Terminal) | 1, Hinweis auf `--once` auf stderr |

## Tasten im TUI

| Taste | Wirkung |
|-------|---------|
| `q` / `Q` | beenden |
| `r` / `R` | Programm mit denselben Optionen neu laden |
| `h` / `H` | Hilfe ein/aus (wird ignoriert, wenn das Overlay nicht ins Terminal passt) |
| `-` | Intervall halbieren (min. 0.5 s) |
| `+` / `=` | Intervall verdoppeln (max. 60 s) |

## TUI-Layout

Die Vollbildansicht gliedert sich von oben nach unten in **System**, **GPU**,
**Ollama** und **History**. CPU, RAM, GPU-Auslastung, VRAM und Power verwenden
pro Terminal dieselbe Balkenbreite; Label, Prozentwert und Detailwert sind
spaltenweise ausgerichtet. Die Farbsyntax ist global: Struktur (Überschriften,
Labels und Rahmen) ist Cyan, Auslastungs- und Temperaturstatus Grün/Gelb/Rot,
Sekundärinfos gedimmt. Im Ollama-Speicherbalken bedeuten die Farben explizit
den Offload-Grad der GPU/VRAM-Anzeige: Grün oberhalb 55 %, Gelb bei 45–55 %
und Rot unterhalb 45 % GPU-Anteil. CPU/RAM bleibt gedimmt grau. Beide Anteile
nutzen `#` und zeigen zusätzlich Textwerte. Eine
Leerzeile trennt jeweils System, GPU, Ollama und History. **History** zeigt
abgeschlossene instrumentierte Runs und speichert zusätzlich lokale, begrenzte
System-Snapshots. Der Snapshot-Pfad kann über `OTOP_HISTORY_FILE`, die
Run-Historie über `OTOP_RUN_HISTORY_FILE` oder `XDG_STATE_HOME` angepasst
werden.

## Angezeigte Werte

* **Kopfzeile**: `otop <VERSION>`, Ollama-Version und Erreichbarkeit
  (`/api/version`), `verbunden` / `OFFLINE` sowie das Refresh-Intervall.
* **Aktuelle Runs**: bis zu drei aktive Schema-2-Runs aus `OTOP_RUN_FILE`, jeweils mit Quelle (`Pi`, `Open WebUI`, `Ollama CLI`), Status, Modell und verfügbaren Token-/Dauerwerten. Schema-1-Daten bleiben als `Legacy` lesbar. Status, Modell, Kontextlimit und grafischer Kontextverbrauch (Prompt- plus Ausgabetoken),
  Prompt-/Ausgabe-/Gesamttoken und Ausgabe-Rate. `--chat` und `--generate`
  instrumentieren eigene direkte Ollama-Aufrufe ohne Reverse Proxy. Während
  des Streamings liefert Ollama keine Tokenwerte; bis zum Abschluss stehen sie
  daher als `n/a` da. Ohne Ereignis wird nichts geschätzt.
* **Geladene Modelle** (`/api/ps`): Name, Parametergröße, Quantisierung,
  `context_length`, Runner, Restzeit bis Auto-Unload (`expires_at`),
  `size_vram` / `size` → Aufteilung GPU % / CPU %. Der Ollama-Bereich ist in
  „Aktuelle Runs“ und „Geladene Modelle“ unterteilt.
* **CPU**: Gesamt-% aus `/proc/stat`-Differenz zwischen zwei Refreshes, dazu
  Load Average (`/proc/loadavg`), Kernanzahl (`os.cpu_count()`) und Temperatur
  aus `k10temp`, `coretemp` oder `zenpower`, sofern verfügbar.
* **RAM**: Auslastung `%`, Größe `GiB`, Zeile direkt nach CPU-Balken
  (aus `/proc/meminfo`).
* **GPU**: Auslastung %, Temperatur und VRAM-belegt/%. Quellenkette: zunächst `nvidia-smi`
  (via `subprocess`, Power W und Leistungsgrenze), bei fehlenden NVIDIA-Daten
  `/sys/class/drm/card*/device/gpu_busy_percent` (sysfs); sonst
  `keine GPU-Quelle gefunden`. `--no-nvidia` verwendet unmittelbar sysfs.
  Der Power-Balken verwendet mindestens die lokale Boost-Skala von 115 W;
  eine höhere gemeldete Leistungsgrenze hat Vorrang.
* **VRAM**: VRAM-Auslastung `%` und Größe in MiB
  (`VRAM [##########  ] 96.5 %  7864 / 8151 MiB`). Im Ollama-Bereich zeigt ein
  geteilter Balken denselben Modell-Speicheranteil: Modellname, „Speicher“ und
  Klammern sind Cyan. GPU/VRAM ist oberhalb 55 % Grün, bei 45–55 % Gelb und
  darunter Rot; CPU/RAM und sein Text bleiben gedimmt grau. Beide Anteile
  verwenden `#`; Prozent- und Größenwerte bleiben daneben lesbar.

## Open-WebUI-Adapter

Der Filter liegt in `open_webui/otop_run_metrics.py` und wird ausschließlich über die Open-WebUI-API installiert. Die lokale `.env` benötigt zusätzlich zu `OTOP_COLLECTOR_TOKEN` einen Admin-API-Key:

```dotenv
OPEN_WEBUI_URL=http://127.0.0.1:3000
OPEN_WEBUI_API_KEY=<Open-WebUI-Admin-API-Key>
```

Danach genügt der normale TUI-Start; der Collector wird bei konfiguriertem
`OTOP_COLLECTOR_TOKEN` automatisch im Hintergrund gestartet:

```bash
python3 otop.py
python3 otop.py --install-open-webui-adapter
```

`--collector` bleibt für einen separat laufenden, blockierenden Dienstmodus
verfügbar.

Der Installationsbefehl erkennt die private Docker-Gateway-Adresse, setzt die Filter-Valves, aktiviert den Filter und schaltet ihn global. Der Filter überträgt ausschließlich Quelle, UUID, Modell, Zeit- und Nutzungswerte. Collector-Fehler werden abgefangen und beeinflussen die Chatantwort nicht.

## Bekannte Grenzen

* Die Ollama-API selbst liefert **keine** CPU-/GPU-Auslastung (nur `size_vram`);
  `/metrics` gibt es hier nicht (404). GPU-Auslastung kommt vom **Host**, sie ist
  geräte-global und nicht exklusiv Ollama zurechenbar.
* Ollama läuft im Docker-Container; die GPU-Messung erfolgt am Host (NVIDIA-Binary
  `nvidia-smi` bzw. sysfs), nicht im Container.
* Der Collector lauscht standardmäßig auf `127.0.0.1:11435` und zusätzlich auf dem erkannten privaten Docker-Gateway von `open-webui`. Er benötigt `OTOP_COLLECTOR_TOKEN`; `.env.example` zeigt die lokalen Variablennamen.
* Run-Historien speichern nur IDs, Quelle, Modell, Status, Zeit- und Tokenzähler
  sowie optional Kontexttoken und Kontextlimit; keine Prompts oder Modellantworten.
  Das Kontextlimit wird bevorzugt aus dem Run (`options.num_ctx`) übernommen und
  ersatzweise aus dem aktuell geladenen Modell in `/api/ps` ergänzt. Open-WebUI
  liefert bei Ollama-Streaming echte Usage-Werte häufig erst im Abschluss;
  währenddessen zeigt otop deshalb einen eindeutigen Wartezustand statt Schätzungen.
* CPU-% ist ein Differenzwert über ein Refresh-Intervall — der erste Frame zeigt
  „Messung“.
* Ist `nvidia-smi` erfolgreich, werden sysfs-GPUs nicht zusätzlich gezeigt.
  Bei mehreren NVIDIA-GPUs werden alle von `nvidia-smi` gemeldeten Geräte gezeigt.
* Schlägt `/api/ps` fehl, zeigt die Anwendung den Fehler statt „kein Modell geladen“.
* Modelle ohne Scrollen: viele geladene Modelle können die GPU-Zeilen aus dem
  Bildschirm schieben.
* TUI braucht ein echtes Terminal (TTY). Ohne TTY: `--once` verwenden.
* Mindest-Terminalgröße 40×18. Darunter zeigt die TUI einen Hinweis, damit
  Fußzeile oder Bereiche nicht überdeckt werden.

## Testumgebung (live)

Ollama 0.40.6 im Docker-Container unter `http://localhost:11434`, GPU NVIDIA
RTX 5070 Laptop (8151 MiB) + AMD iGPU (`card2`), 24 Kerne, Python 3.12.
Aktueller Prüfstatus und bekannte Grenzen: siehe `status.md`.
